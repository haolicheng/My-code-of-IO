#include <bits/stdc++.h>
using namespace std;
int a[1005],n,i;
int cmp(int i,int j) {return i<j;}
int main()
{
	freopen("a.in","r",stdin);
	freopen("b.out","w",stdout);
	cin>>n;
	for (i=1; i<=n; i++) cin>>a[i];
	sort(a+1,a+n+1,cmp);
	for (i=1; i<=n; i++) cout<<a[i]<<' ';
	return 0;
}
