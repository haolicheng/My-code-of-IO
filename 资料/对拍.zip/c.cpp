#include <bits/stdc++.h>
using namespace std;
int main()
{
	srand((unsigned)time(NULL));
	freopen("a.in","w",stdout);
	int n=rand()%100+1; // n= 1~100
	cout<<n<<endl;
	for (int i=1; i<=n; i++) cout<<rand()%1000+1<<' ';   // 1~1000
	return 0;
}
