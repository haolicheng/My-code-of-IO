#include <bits/stdc++.h>
using namespace std;
int a[1005],n,i,j;
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	cin>>n;
	for (i=1; i<=n; i++) cin>>a[i];
	for (i=1; i<=n; i++)
	  for (j=i+1; j<=n; j++)
	    if (a[i]>a[j]) swap(a[i],a[j]);
	for (i=1; i<=n; i++) cout<<a[i]<<' ';
	return 0;
}
